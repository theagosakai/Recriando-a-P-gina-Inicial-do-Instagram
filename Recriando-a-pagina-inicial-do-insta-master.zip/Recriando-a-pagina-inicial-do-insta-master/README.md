<h1 align="center"> Recriando a pagina inicial do instagram </h1>

<p align="center">
    <img alt="GitHub language count" src="https://img.shields.io/github/languages/count/gabriel4420/Recriando-a-pagina-inicial-do-insta">

  <img alt="GitHub top language" src="https://img.shields.io/github/languages/top/gabriel4420/Recriando-a-pagina-inicial-do-insta?logo=html">

  <img alt="GitHub repo size in bytes" src="https://img.shields.io/github/repo-size/gabriel4420/Recriando-a-pagina-inicial-do-insta?color=green">

  <br>

  <img alt="GitHub code size in bytes" src="https://img.shields.io/github/last-commit/Gabriel4420/Recriando-a-pagina-inicial-do-insta">

  <a href="https://www.linkedin.com/in/gabriel-rodrigues-perez-2069b072/">
    <img alt="Made by Gabriel" src="https://img.shields.io/badge/made%20by-Gabriel-%2304D361">
  </a>

  
</p>

![](principal.png)

<p>Este é um projeto feito pela digital innovation one e adaptado por mim, dentro deste projeto foi transpassado lições sobre : HTML5 e CSS3. </p>
<p>
<h2>Principais tópicos abordados</h2>
<ul align="left">
  <li>hierarquia de tags</li>
  <li>flex-layout</li>
  <li>grid-layout</li>
  <li>css tricks</li>
</ul>

</p>